﻿using Microsoft.EntityFrameworkCore;
using HireWave.Models;

namespace HireWave.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<JobPost> JobPosts { get; set; }
        public DbSet<Applicant> Applicants { get; set; }

        public DbSet<Query> Queries { get; set; }
    }
}