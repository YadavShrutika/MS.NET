﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HireWave.Models
{
    public class Applicant
    {
        [Key]
        public int ApplicantId { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required]
        public string ContactNumber { get; set; }

        public string Address { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public string EducationLevel { get; set; }

        [Required]
        public int GraduationYear { get; set; }

        public string WorkExperience { get; set; }

        [Required]
        public string KeySkills { get; set; }

        public int JobPostId { get; set; }
    }
}

