﻿using System.ComponentModel.DataAnnotations;

namespace HireWave.Models
{
    public class JobPost
    {
        [Key]
        public int JobId { get; set; }

        [Required(ErrorMessage = "Job title is required.")]
        [StringLength(100, ErrorMessage = "Job title must be between 3 and 100 characters.", MinimumLength = 3)]
        public string JobTitle { get; set; }

        [Required(ErrorMessage = "Company name is required.")]
        [StringLength(100, ErrorMessage = "Company name must be between 3 and 100 characters.", MinimumLength = 3)]
        public string CompanyName { get; set; }

        [Required(ErrorMessage = "Job location is required.")]
        [StringLength(100, ErrorMessage = "Job location must be between 3 and 100 characters.", MinimumLength = 3)]
        public string JobLocation { get; set; }

        [Required(ErrorMessage = "Job description is required.")]
        [StringLength(1000, ErrorMessage = "Job description must be at least 20 characters long.", MinimumLength = 20)]
        public string JobDescription { get; set; }

        [Required(ErrorMessage = "Package is required.")]
        [Range(1, 100, ErrorMessage = "Package must be a valid number between 1 and 100 LPA.")]
        public double JobPackage { get; set; }  // Package in LPA

        [Required(ErrorMessage = "Job type is required.")]
        public string JobType { get; set; }

    }
}
