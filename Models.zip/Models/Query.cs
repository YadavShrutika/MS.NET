﻿using System.ComponentModel.DataAnnotations;

namespace HireWave.Models
{
    public class Query
    {
        [Key] // Marks the Id as the primary key
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
        public DateTime PostedAt { get; set; } = DateTime.Now;
    }
}
