﻿using System.ComponentModel.DataAnnotations;

namespace HireWave.Models
{
    public class User
    {
        // Unique identifier for the user
        public int UserId { get; set; }

        // Name field with validation
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name can't be longer than 100 characters")]
        public string Name { get; set; }

        // Email field with updated validation (requires '@' symbol)
        [Required(ErrorMessage = "Email is required")]
        [RegularExpression(@".+@.+\..+", ErrorMessage = "Email must contain the '@' symbol and a valid domain (e.g., example@domain.com).")]
        [StringLength(100, ErrorMessage = "Email can't be longer than 100 characters")]
        public string Email { get; set; }

        // Password field with validation for complexity
        [Required(ErrorMessage = "Password is required")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be between 6 and 100 characters")]
        [RegularExpression(@"^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$",
            ErrorMessage = "Password must start with an uppercase letter, contain at least one special symbol, and at least one number.")]
        public string Password { get; set; }

        // Role field with validation for allowed values (JobSeeker or Recruiter)
        [Required(ErrorMessage = "Role is required")]
        [RegularExpression(@"^(JobSeeker|Recruiter)$", ErrorMessage = "Role must be either 'JobSeeker' or 'Recruiter'")]
        public string Role { get; set; } // Allowed roles: JobSeeker or Recruiter
    }
}
