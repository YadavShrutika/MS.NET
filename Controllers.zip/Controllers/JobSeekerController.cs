﻿using HireWave.Data;
using HireWave.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HireWave.Controllers
{
    public class JobSeekerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public JobSeekerController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Dashboard()
        {
            return View();
        }

        // Action to view job posts in card format
        public IActionResult ViewPost()
        {
            var jobPosts = _context.JobPosts.ToList(); // Fetch all job posts from the database
            return View(jobPosts); // Pass job posts to the view
        }

        public IActionResult ContactUs()
        {
            return View();
        }
         [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult PostQueries(Query query)
        {
            if (ModelState.IsValid)
            {
                query.PostedAt = DateTime.Now; // Set the current time for the query
                _context.Queries.Add(query);
                _context.SaveChanges(); // Save to the database

                ViewBag.SuccessMessage = "Your query has been successfully submitted!";
                return RedirectToAction("ContactUs"); // Redirect back to the contact form
            }

            // If validation fails, return the view with the existing model data
            return View("ContactUs", query);
        }
    }
}
