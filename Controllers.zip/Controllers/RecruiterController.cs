﻿using HireWave.Data;
using HireWave.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace HireWave.Controllers
{
    public class RecruiterController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RecruiterController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Recruiter/PostJob
        public IActionResult PostJob()
        {
            return View();
        }

        // GET: Recruiter/Dashboard
        public IActionResult Dashboard()
        {
            return View();
        }

        // POST: Recruiter/PostJob
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult PostJob(JobPost jobPost)
        {
            if (ModelState.IsValid)
            {
                _context.JobPosts.Add(jobPost);
                _context.SaveChanges();
                TempData["SuccessMessage"] = "Job posted successfully!";
                return RedirectToAction("Jobs");
            }
            return View(jobPost);
        }

        // GET: Recruiter/Jobs
        public IActionResult Jobs()
        {
            var jobPosts = _context.JobPosts.ToList();
            return View(jobPosts);
        }

      

        // POST: Recruiter/ContactUs

        // GET: Recruiter/ViewQueries
        public IActionResult ViewQueries()
        {
            // Retrieve all queries from the database
            var queries = _context.Queries.ToList();
            return View(queries);
        }

        // GET: Recruiter/Edit
        public IActionResult Edit(int jobId)
        {
            var jobPost = _context.JobPosts.FirstOrDefault(j => j.JobId == jobId);
            if (jobPost == null)
            {
                TempData["ErrorMessage"] = "Job not found.";
                return RedirectToAction("Jobs");
            }
            return View(jobPost);
        }

        // POST: Recruiter/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(JobPost jobPost)
        {
            if (ModelState.IsValid)
            {
                var jobInDb = _context.JobPosts.FirstOrDefault(j => j.JobId == jobPost.JobId);

                if (jobInDb != null)
                {
                    jobInDb.JobTitle = jobPost.JobTitle;
                    jobInDb.CompanyName = jobPost.CompanyName;
                    jobInDb.JobLocation = jobPost.JobLocation;
                    jobInDb.JobDescription = jobPost.JobDescription;
                    jobInDb.JobPackage = jobPost.JobPackage;
                    jobInDb.JobType = jobPost.JobType;

                    _context.SaveChanges();
                    TempData["SuccessMessage"] = "Job updated successfully!";
                    return RedirectToAction("Jobs");
                }
            }

            TempData["ErrorMessage"] = "Failed to update the job post.";
            return View(jobPost);
        }

        // POST: Recruiter/Delete
        [HttpPost]
        public IActionResult Delete(int jobId)
        {
            var jobPost = _context.JobPosts.FirstOrDefault(j => j.JobId == jobId);
            if (jobPost != null)
            {
                _context.JobPosts.Remove(jobPost);
                _context.SaveChanges();
                TempData["SuccessMessage"] = "Job deleted successfully!";
            }
            else
            {
                TempData["ErrorMessage"] = "Job not found.";
            }
            return RedirectToAction("Jobs");
        }
        // GET: Recruiter/Applicants
        public IActionResult Applicants()
        {
            var applicants = _context.Applicants.ToList();
            return View(applicants);
        }
    }
}
