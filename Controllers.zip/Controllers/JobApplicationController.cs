﻿using HireWave.Data;
using HireWave.Models;
using Microsoft.AspNetCore.Mvc;

namespace HireWave.Controllers
{
    public class JobApplicationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public JobApplicationController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Apply(int jobPostId)
        {
            var applicant = new Applicant { JobPostId = jobPostId };
            return View(applicant);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Apply(Applicant applicant)
        {
            if (ModelState.IsValid)
            {
                _context.Applicants.Add(applicant);
                _context.SaveChanges();
                TempData["SuccessMessage"] = "Application submitted successfully!";
                return RedirectToAction("Dashboard", "JobSeeker");
            }

            return View(applicant);
        }

        public IActionResult ViewApplicants()
        {
            var applicants = _context.Applicants.ToList();
            return View(applicants);
        }
    }
}
